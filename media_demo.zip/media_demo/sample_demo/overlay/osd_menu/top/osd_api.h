#ifndef _OSD_API_H_
#define _OSD_API_H_

void set_textbox(char *str);
int osd_isSleeping();

#endif  // !_OSD_API_H_