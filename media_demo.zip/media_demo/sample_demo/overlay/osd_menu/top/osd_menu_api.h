#ifndef _OSD_API_H_
#define _OSD_API_H_

void setTextboxAeStatus(char *str);

#endif  // !_OSD_API_H_