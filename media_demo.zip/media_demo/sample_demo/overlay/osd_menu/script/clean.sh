if [ -e __pycache__ ];then rm -r __pycache__; fi
if [ -e callback ];then rm -r callback; fi
if [ -e menu ];then rm -r menu; fi
if [ -e string ];then rm -r string; fi
if [ -e user ];then rm -r user; fi
if [ -e font ];then rm -r font; fi
if [ -e fontcombine.sh ];then rm fontcombine.sh; fi
if [ -e gencode.sh ];then rm gencode.sh; fi
if [ -e initDic.sh ];then rm initDic.sh; fi
if [ -e gendic.sh ];then rm gendic.sh; fi
if [ -e genfont.sh ];then rm genfont.sh; fi
if [ -e genstr.sh ];then rm genstr.sh; fi
if [ -e genstrmap.sh ];then rm genstrmap.sh; fi
if [ -e strcombine.sh ];then rm strcombine.sh; fi
if [ -e genstring.sh ];then rm genstring.sh; fi
