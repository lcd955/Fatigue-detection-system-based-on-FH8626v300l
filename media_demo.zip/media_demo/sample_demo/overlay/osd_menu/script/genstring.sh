# extract string from ini file
# OsdStringGenIPC.py <input_ini> 

python3 OsdStringGenIPC.py ./in/main.ini
python3 OsdStringGenIPC.py ./in/ae.ini
python3 OsdStringGenIPC.py ./in/awb.ini
python3 OsdStringGenIPC.py ./in/dayNight.ini
python3 OsdStringGenIPC.py ./in/imageEnhance.ini
python3 OsdStringGenIPC.py ./in/videoOutput.ini
python3 OsdStringGenIPC.py ./in/sleep.ini
python3 OsdStringGenIPC.py ./in/confirm.ini
