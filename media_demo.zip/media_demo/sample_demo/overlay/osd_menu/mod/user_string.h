#ifndef _USER_STRING_H_
#define _USER_STRING_H_
#include "user_menu.h"

#define MAX_STR_LEN 32
#define MAX_COMPONENT_PER_NUM 32

extern char *osd_string_index[MENU_NUM];

#endif
