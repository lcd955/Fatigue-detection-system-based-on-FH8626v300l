#ifndef _COMPONENTS_H_
#define _COMPONENTS_H_

#include "osd_obj_menu.h"
#include "osd_obj_button.h"
#include "osd_obj_scrollbar.h"
#include "osd_obj_combobox.h"
#include "osd_obj_textbox.h"
#include "osd_obj_combobutton.h"

#endif
