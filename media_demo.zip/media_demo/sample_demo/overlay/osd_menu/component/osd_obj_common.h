#ifndef _OSD_OBJ_COMMON_H_
#define _OSD_OBJ_COMMON_H_
#include "stdio.h"
#include "string.h"
#include "../core/osd_obj.h"
#include "../core/osd_draw.h"
void obj_set_title_string(osd_obj_t *obj);
void obj_osd_draw(osd_obj_t *obj);

#endif // !_OSD_OBJ_COMMON_H_