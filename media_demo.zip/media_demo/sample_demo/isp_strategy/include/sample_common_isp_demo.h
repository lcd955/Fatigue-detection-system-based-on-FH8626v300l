#ifndef __SAMPLE_COMMON_ISP_DEMO_H__
#define __SAMPLE_COMMON_ISP_DEMO_H__
#include "isp_config.h"

FH_SINT32 sample_fh_isp_demo_start(FH_SINT32 grp_id);

FH_SINT32 sample_fh_isp_demo_stop(FH_SINT32 grp_id);

#endif /* __SAMPLE_COMMON_ISP_DEMO_H__ */
