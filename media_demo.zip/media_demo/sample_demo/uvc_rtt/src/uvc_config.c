#include "uvc_rtt/include/uvc_config.h"

// static char *model_name = MODEL_TAG_UVC_CONFIG;
