#ifndef __SAMPLE_COMMON_COOL_VIEW_H__
#define __SAMPLE_COMMON_COOL_VIEW_H__
#include "sample_common_media.h"

FH_SINT32 sample_common_start_coolview(FH_VOID);

FH_SINT32 sample_common_stop_coolview(FH_VOID);

#endif // __SAMPLE_COMMON_COOL_VIEW_H__
