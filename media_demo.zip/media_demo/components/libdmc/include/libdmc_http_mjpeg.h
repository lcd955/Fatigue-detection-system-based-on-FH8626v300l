#ifndef __libdmc_http_mjpeg_h__
#define __libdmc_http_mjpeg_h__
#include "types/type_def.h"

extern FH_SINT32 dmc_http_mjpeg_subscribe(FH_UINT16 port);
extern FH_SINT32 dmc_http_mjpeg_unsubscribe(FH_VOID);

#endif /*__libdmc_http_mjpeg_h__*/
