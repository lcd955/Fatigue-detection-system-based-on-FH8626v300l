#ifndef __libdmc_record_h__
#define __libdmc_record_h__

extern int dmc_record_subscribe(int rawgrp);
extern int dmc_record_unsubscribe(void);

#endif /*__libdmc_record_h__*/
