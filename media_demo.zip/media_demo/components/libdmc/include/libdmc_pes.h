#ifndef __libdmc_pes_h__
#define __libdmc_pes_h__

extern int dmc_pes_subscribe(int pesgrp, char* ip, int port);
extern int dmc_pes_unsubscribe(void);

#endif /*__libdmc_pes_h__*/
