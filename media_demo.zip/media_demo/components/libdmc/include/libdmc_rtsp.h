#ifndef __libdmc_rtsp_h__
#define __libdmc_rtsp_h__

extern int dmc_rtsp_subscribe(int rtspgrp, int port);
extern int dmc_rtsp_unsubscribe(void);

#endif /*__libdmc_rtsp_h__*/
