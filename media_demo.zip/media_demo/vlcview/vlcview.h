#ifndef __VLCVIEW_H__
#define __VLCVIEW_H__

extern int _vlcview(char *dst_ip, unsigned int port);
extern int _vlcview_exit(void);

#endif /*__VLCVIEW_H__*/
