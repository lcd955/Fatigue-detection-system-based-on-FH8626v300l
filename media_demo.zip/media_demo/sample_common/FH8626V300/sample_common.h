#ifndef __SAMPLE_COMMON_H__
#define __SAMPLE_COMMON_H__

#include "sample_common_media.h"

// User App Include
#include "sample_common_isp.h"
#include "sample_common_dsp.h"
#include "stream/include/sample_common_stream.h"
#include "coolview/include/sample_common_coolview.h"
#include "sample_common_demo.h"

#endif // __SAMPLE_COMMON_H__
