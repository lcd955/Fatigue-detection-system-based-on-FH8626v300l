#ifndef __SAMPLE_COMMON_VICAP_H__
#define __SAMPLE_COMMON_VICAP_H__
#include "sample_common_media.h"
#include "isp_config.h"
#include "vicap/fh_vicap_mpi.h"

FH_SINT32 sample_common_vicap_get_frame_blk_size(FH_SINT32 grp_id, FH_UINT32 *blk_size);

#endif // __SAMPLE_COMMON_VICAP_H__
