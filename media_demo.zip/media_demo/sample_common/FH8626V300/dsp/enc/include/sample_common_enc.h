#ifndef __SAMPLE_COMMON_ENC_H__
#define __SAMPLE_COMMON_ENC_H__
#include "sample_common_media.h"
#include "dsp/fh_venc_mpi.h"
#include "enc_config.h"
#include "vpu_config.h"

FH_SINT32 sample_common_enc_init(FH_VOID);

#endif // __SAMPLE_COMMON_ENC_H__
