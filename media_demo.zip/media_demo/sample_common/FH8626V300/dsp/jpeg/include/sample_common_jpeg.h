#ifndef __SAMPLE_COMMON_JPEG_H__
#define __SAMPLE_COMMON_JPEG_H__
#include "sample_common_media.h"
#include "jpeg_config.h"
#include "vpu_bind_info.h"

FH_SINT32 sample_common_mjpeg_start(FH_VOID);

FH_SINT32 sample_common_mjpeg_stop(FH_VOID);

#endif // __SAMPLE_COMMON_JPEG_H__
