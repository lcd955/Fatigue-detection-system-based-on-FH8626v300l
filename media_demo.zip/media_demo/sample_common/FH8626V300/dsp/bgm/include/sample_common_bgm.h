#ifndef __SAMPLE_COMMON_BGM_H__
#define __SAMPLE_COMMON_BGM_H__
#include "sample_common_dsp.h"
#include "bgm_config.h"

FH_SINT32 sample_common_bgm_init(FH_VOID);

FH_SINT32 sample_common_bgm_exit(FH_VOID);

#endif // __SAMPLE_COMMON_BGM_H__
